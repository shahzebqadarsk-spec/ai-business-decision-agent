"""Generator configuration.

`start_month`, `months` and `currency` are locked by the Phase 0 business
decisions: January 2023 - December 2025, 36 months, PKR. They are still
ordinary fields (not hard-coded constants) so the generator stays
future-proof for a different engagement, but an attempt to override them
away from the approved values raises immediately rather than silently
producing an inconsistent dataset.
"""

from __future__ import annotations

from datetime import date

from pydantic import BaseModel, Field, field_validator

_MIN_EFFECTIVE_CUSTOMERS = 15
_MIN_EFFECTIVE_EMPLOYEES = 30


class SizesConfig(BaseModel):
    customers: int = 300
    employees: int = 250


class PlantedConfig(BaseModel):
    # A. Procurement: ~17% repricing on one supplier/material pair, last 4 quarters.
    procurement_supplier_id: str = "SUP-04"
    procurement_material_id: str = "MAT-01"
    procurement_increase_target: float = 0.17
    procurement_quarters_affected: int = 4

    # B. Region: one region in meaningful decline over the series.
    region_decline_id: str = "REG-05"
    region_decline_target: float = -0.45

    # C. Product: one product with deteriorating margin (rising cost, capped price).
    margin_decline_product_id: str = "PROD-12"
    margin_decline_target_pp: float = 0.10  # margin-percentage-point deterioration

    # D. Overtime: staffing gap on one line drives rising overtime.
    overtime_line_id: str = "LINE-05"
    staffing_gap: int = 9
    overtime_target_hours_per_month: float = 400.0

    # E. Inventory: overstock bias on one product.
    inventory_imbalance_product_id: str = "PROD-20"
    inventory_overstock_target_months_of_cover: float = 3.5


class GeneratorConfig(BaseModel):
    seed: int = 42
    start_month: date = Field(default=date(2023, 1, 1))
    months: int = 36
    currency: str = "PKR"
    scale: float = 1.0
    sizes: SizesConfig = Field(default_factory=SizesConfig)
    planted: PlantedConfig = Field(default_factory=PlantedConfig)
    write_messy: bool = True

    @field_validator("start_month")
    @classmethod
    def _start_month_locked(cls, value: date) -> date:
        if value != date(2023, 1, 1):
            raise ValueError("start_month is locked to 2023-01-01 (Phase 0 decision).")
        return value

    @field_validator("months")
    @classmethod
    def _months_locked(cls, value: int) -> int:
        if value != 36:
            raise ValueError("months is locked to 36 (Phase 0 decision).")
        return value

    @field_validator("currency")
    @classmethod
    def _currency_locked(cls, value: str) -> str:
        if value != "PKR":
            raise ValueError("currency is locked to PKR (Phase 0 decision).")
        return value

    @property
    def effective_sizes(self) -> SizesConfig:
        """Sizes after applying `scale`, with floors so a tiny scale still yields a usable dataset.

        `scale` exists purely so tests can run a fast, small dataset without changing the
        business model itself: it shrinks headcount/customer counts proportionally rather
        than changing which entities exist.
        """
        return SizesConfig(
            customers=max(_MIN_EFFECTIVE_CUSTOMERS, round(self.sizes.customers * self.scale)),
            employees=max(_MIN_EFFECTIVE_EMPLOYEES, round(self.sizes.employees * self.scale)),
        )
