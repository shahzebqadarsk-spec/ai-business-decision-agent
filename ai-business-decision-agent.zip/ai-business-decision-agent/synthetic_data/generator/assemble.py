"""Assembles every dimension and fact table into one dict of DataFrames."""

from __future__ import annotations

import pandas as pd

from generator.catalog import CATEGORIES, LINES, MATERIALS, PLANTS, PRODUCTS, REGIONS, SUPPLIERS
from generator.config import GeneratorConfig
from generator.costs import generate_expenses
from generator.dimensions import Customer, Employee, build_customers, build_employees
from generator.procurement import generate_procurement
from generator.rng import StreamFactory
from generator.sales import generate_sales
from generator.supply import generate_supply
from generator.workforce import generate_workforce


def _dim_dataframes(
    customers: tuple[Customer, ...], employees: tuple[Employee, ...]
) -> dict[str, pd.DataFrame]:
    return {
        "regions": pd.DataFrame([r.__dict__ for r in REGIONS]),
        "categories": pd.DataFrame([c.__dict__ for c in CATEGORIES]),
        "products": pd.DataFrame([p.__dict__ for p in PRODUCTS]),
        "customers": pd.DataFrame([c.__dict__ for c in customers]),
        "suppliers": pd.DataFrame([s.__dict__ for s in SUPPLIERS]),
        "materials": pd.DataFrame([m.__dict__ for m in MATERIALS]),
        "employees": pd.DataFrame([e.__dict__ for e in employees]),
        "plants": pd.DataFrame([p.__dict__ for p in PLANTS]),
        "lines": pd.DataFrame([line.__dict__ for line in LINES]),
    }


def assemble_dataset(config: GeneratorConfig, streams: StreamFactory) -> dict[str, pd.DataFrame]:
    customers = build_customers(config, streams.stream("dimensions.customers"))
    employees = build_employees(config, streams.stream("dimensions.employees"))

    sales = generate_sales(
        config,
        customers,
        rng_lines=streams.stream("sales.lines"),
        rng_product=streams.stream("sales.product"),
        rng_qty=streams.stream("sales.qty"),
        rng_noise=streams.stream("sales.noise"),
    )
    procurement = generate_procurement(
        config,
        rng_qty=streams.stream("procurement.qty"),
        rng_noise=streams.stream("procurement.noise"),
    )
    production, inventory = generate_supply(config, sales, rng_noise=streams.stream("supply.noise"))
    payroll, overtime = generate_workforce(
        config, employees, sales, rng_noise=streams.stream("workforce.noise")
    )
    expenses = generate_expenses(config, rng_noise=streams.stream("costs.noise"))

    tables = _dim_dataframes(customers, employees)
    tables.update(
        {
            "sales": sales,
            "procurement": procurement,
            "production": production,
            "inventory": inventory,
            "payroll": payroll,
            "overtime": overtime,
            "expenses": expenses,
        }
    )
    return tables
