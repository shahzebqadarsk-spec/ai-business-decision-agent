"""Procurement (purchase order) generation.

The planted procurement problem (GT-01) requires one *specific* supplier to
be the one supplying one *specific* material, so the repricing multiplier
has something to attach to. Materials are assigned a supplier deterministically
from `catalog.MATERIAL_BY_ID[...].default_supplier_id` -- not by a random
weighted draw -- precisely so the planted pair is never accidentally broken
by a different seed (an earlier version of this generator drew supplier
assignment randomly per seed, which silently erased the planted problem in
most seeds; see docs/DECISIONS.md).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from generator.catalog import MATERIALS
from generator.config import GeneratorConfig
from generator.macro import cpi_index, months
from generator.planted import procurement_repricing_factor, red_herring_one_off_supplier_spike

_BASE_ORDERS_PER_MATERIAL_PER_MONTH = 3


def generate_procurement(
    config: GeneratorConfig, rng_qty: np.random.Generator, rng_noise: np.random.Generator
) -> pd.DataFrame:
    month_list = months()
    cpi = cpi_index(month_list)
    planted = config.planted

    rows: list[dict[str, object]] = []
    po_counter = 0
    for m_idx, m in enumerate(month_list):
        for material in MATERIALS:
            supplier_id = material.default_supplier_id
            for _ in range(_BASE_ORDERS_PER_MATERIAL_PER_MONTH):
                price_factor = cpi[m]
                is_planted_pair = (
                    supplier_id == planted.procurement_supplier_id
                    and material.id == planted.procurement_material_id
                )
                if is_planted_pair:
                    price_factor *= procurement_repricing_factor(m_idx, planted)
                price_factor *= red_herring_one_off_supplier_spike(m_idx, supplier_id=supplier_id)

                unit_price = round(material.base_unit_cost_pkr * price_factor, 2)
                quantity = max(1, round(rng_qty.lognormal(mean=6.5, sigma=0.35)))
                noise = float(rng_noise.normal(loc=1.0, scale=0.03))
                amount = round(unit_price * quantity * noise, 2)

                po_counter += 1
                rows.append(
                    {
                        "po_id": f"PO-{po_counter:06d}",
                        "month": m.isoformat(),
                        "po_date": m.isoformat(),
                        "supplier_id": supplier_id,
                        "material_id": material.id,
                        "quantity": int(quantity),
                        "unit_price_pkr": unit_price,
                        "amount_pkr": amount,
                        "currency": config.currency,
                    }
                )
    return pd.DataFrame(rows)
