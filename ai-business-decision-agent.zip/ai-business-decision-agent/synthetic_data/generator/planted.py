"""Pure multiplier functions for the five planted business problems.

Each function takes the month index (0-based across the 36-month series) and
returns a multiplier close to 1.0 in early months, diverging over time. They
are applied inside ordinary generation mechanics (price, demand, staffing,
inventory) -- never as a label on a row -- so a problem is only recoverable
by *measuring* the written output tables (see `measure.py`), the same way a
real analyst would have to.
"""

from __future__ import annotations

from generator.config import PlantedConfig

_TOTAL_MONTHS = 36
_LAST_4_QUARTERS_START_MONTH = _TOTAL_MONTHS - 12  # month index 24: start of the affected window


def procurement_repricing_factor(month_idx: int, planted: PlantedConfig) -> float:
    """Supplier/material-specific repricing, ramping up over the last 4 quarters only."""
    if month_idx < _LAST_4_QUARTERS_START_MONTH:
        return 1.0
    progress = (month_idx - _LAST_4_QUARTERS_START_MONTH + 1) / 12.0
    return 1.0 + planted.procurement_increase_target * progress


def region_decline_factor(month_idx: int, planted: PlantedConfig) -> float:
    """Gradual, roughly linear decline across the whole series for the affected region."""
    progress = month_idx / (_TOTAL_MONTHS - 1)
    return 1.0 + planted.region_decline_target * progress


def margin_decline_cost_multiplier(month_idx: int, planted: PlantedConfig) -> float:
    """Rising unit cost for the affected product, independent of macro inflation."""
    progress = month_idx / (_TOTAL_MONTHS - 1)
    return 1.0 + planted.margin_decline_target_pp * 2.6 * progress


def margin_decline_price_cap(month_idx: int, planted: PlantedConfig) -> float:
    """Price held roughly flat (slightly *below* what cost pressure alone would require),
    which is what actually squeezes the margin -- cost rising while price cannot follow,
    e.g. because of a fixed-price contract or competitive pressure."""
    progress = month_idx / (_TOTAL_MONTHS - 1)
    return 1.0 + planted.margin_decline_target_pp * 0.3 * progress


def staffing_gap_overtime_pressure(month_idx: int, planted: PlantedConfig) -> float:
    """Demand/workload pressure multiplier on the understaffed line, ramping with
    company-wide demand growth so overtime becomes material only in later months."""
    progress = month_idx / (_TOTAL_MONTHS - 1)
    return 1.0 + 0.9 * progress


def inventory_overstock_bias(month_idx: int, planted: PlantedConfig) -> float:
    """Extra production-vs-shipment slack for the affected product, growing over time.

    Because nothing consumes the resulting excess stock, even a modest sustained
    over-production ratio compounds into a large months-of-cover figure over 36 months --
    this coefficient is deliberately small relative to the others in this module.
    """
    progress = month_idx / (_TOTAL_MONTHS - 1)
    return 1.0 + 0.10 * progress


# --- Red herrings: patterns that could look planted but are not ------------------------


def red_herring_seasonal_product_spike(
    calendar_month: int, *, product_id: str, trigger_product_id: str = "PROD-04"
) -> float:
    """A yarn product with an unusually sharp (but purely seasonal, non-cumulative) spike
    every Ramadan/Eid season -- easy to mistake for a planted anomaly if a reviewer only
    looks at month-over-month deltas instead of the full 3-year pattern."""
    if product_id != trigger_product_id:
        return 1.0
    return 1.35 if calendar_month in (3, 4) else 1.0


def red_herring_one_off_supplier_spike(
    month_idx: int, *, supplier_id: str, trigger_supplier_id: str = "SUP-11", trigger_month_idx: int = 14
) -> float:
    """A one-month price spike (e.g. a logistics disruption) that fully reverts the next
    month -- unlike the planted procurement problem, which is sustained and cumulative."""
    if supplier_id != trigger_supplier_id or month_idx != trigger_month_idx:
        return 1.0
    return 1.22


def red_herring_region_single_month_dip(
    month_idx: int, *, region_id: str, trigger_region_id: str = "REG-02", trigger_month_idx: int = 7
) -> float:
    """A single bad month for a healthy region (e.g. a flood-disrupted month in 2023) --
    looks alarming in isolation but has no trend, unlike the planted regional decline."""
    if region_id != trigger_region_id or month_idx != trigger_month_idx:
        return 1.0
    return 0.55
