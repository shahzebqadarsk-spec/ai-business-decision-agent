"""Programmatic integrity checks on the generated (clean) tables.

Each `_check_*` function returns a list of problem strings (empty = passed).
`verify_tables()` aggregates them; a non-empty result should fail the build.
Written as small, independent, mutation-testable checks so a corrupted copy
of the data reliably trips the *specific* check that should catch it
(see tests/synthetic/test_integrity.py).
"""

from __future__ import annotations

from datetime import date

import pandas as pd

from generator.catalog import (
    CATEGORIES,
    LINES,
    MATERIALS,
    PLANTS,
    PRODUCTS,
    REGIONS,
    SUPPLIERS,
)
from generator.macro import months

_INVOICE_DATE_GRACE_DAYS = 10
_TODAY = date(2026, 10, 7)


def _check_required_entities(tables: dict[str, pd.DataFrame]) -> list[str]:
    problems = []
    checks = [
        ("regions", {r.id for r in REGIONS}, "id"),
        ("categories", {c.id for c in CATEGORIES}, "id"),
        ("products", {p.id for p in PRODUCTS}, "id"),
        ("suppliers", {s.id for s in SUPPLIERS}, "id"),
        ("materials", {m.id for m in MATERIALS}, "id"),
        ("plants", {p.id for p in PLANTS}, "id"),
        ("lines", {line.id for line in LINES}, "id"),
    ]
    for table_name, expected_ids, col in checks:
        actual_ids = set(tables[table_name][col])
        if actual_ids != expected_ids:
            problems.append(f"{table_name}: expected ids {expected_ids} but found {actual_ids}")
    return problems


def _check_36_months(tables: dict[str, pd.DataFrame]) -> list[str]:
    expected_months = {m.isoformat() for m in months()}
    problems = []
    for table_name in ("sales", "procurement", "production", "inventory", "overtime", "expenses"):
        actual_months = set(tables[table_name]["month"])
        missing = expected_months - actual_months
        if missing:
            problems.append(f"{table_name}: missing months {sorted(missing)}")
    return problems


def _check_no_future_dates(tables: dict[str, pd.DataFrame]) -> list[str]:
    problems = []
    sales = tables["sales"]
    order_dates = pd.to_datetime(sales["order_date"])
    if (order_dates.dt.date > date(2025, 12, 31)).any():
        problems.append("sales.order_date: found dates after the locked span end (2025-12-31)")

    invoice_dates = pd.to_datetime(sales["invoice_date"])
    grace_cutoff = pd.Timestamp(date(2025, 12, 31)) + pd.Timedelta(days=_INVOICE_DATE_GRACE_DAYS)
    if (invoice_dates > grace_cutoff).any():
        problems.append(
            f"sales.invoice_date: found dates beyond the {_INVOICE_DATE_GRACE_DAYS}-day "
            "post-period grace window"
        )
    return problems


def _check_currency_and_units(tables: dict[str, pd.DataFrame]) -> list[str]:
    problems = []
    for table_name in ("sales", "procurement", "expenses"):
        df = tables[table_name]
        if "currency" in df.columns and not (df["currency"] == "PKR").all():
            problems.append(f"{table_name}.currency: found a non-PKR value")
    if (tables["sales"]["quantity"] <= 0).any():
        problems.append("sales.quantity: found a non-positive quantity")
    return problems


def _check_gross_amount_arithmetic(tables: dict[str, pd.DataFrame]) -> list[str]:
    sales = tables["sales"]
    expected = (sales["quantity"] * sales["unit_price_pkr"]).round(2)
    mismatch = (expected - sales["gross_amount_pkr"]).abs() > 0.01
    if mismatch.any():
        return [f"sales.gross_amount_pkr: arithmetic mismatch in {int(mismatch.sum())} row(s)"]
    return []


def _check_inventory_identity(tables: dict[str, pd.DataFrame]) -> list[str]:
    inv = tables["inventory"]
    expected_closing = (inv["opening_stock_units"] + inv["produced_units"] - inv["shipped_units"]).round(2)
    mismatch = (expected_closing - inv["closing_stock_units"]).abs() > 0.5
    if mismatch.any():
        return [f"inventory: stock identity broken in {int(mismatch.sum())} row(s)"]
    return []


def _check_row_counts(tables: dict[str, pd.DataFrame], *, scale: float) -> list[str]:
    n = len(tables["sales"])
    low, high = 90_000 * scale, 350_000 * scale
    if not (low <= n <= high):
        return [f"sales: row count {n} outside the expected {low:.0f}-{high:.0f} band for scale={scale}"]
    return []


_UNSCALED_CHECKS = (
    _check_required_entities,
    _check_36_months,
    _check_no_future_dates,
    _check_currency_and_units,
    _check_gross_amount_arithmetic,
    _check_inventory_identity,
)


def verify_tables(tables: dict[str, pd.DataFrame], *, scale: float = 1.0) -> list[str]:
    problems: list[str] = []
    for check in _UNSCALED_CHECKS:
        problems.extend(check(tables))
    problems.extend(_check_row_counts(tables, scale=scale))
    return problems
