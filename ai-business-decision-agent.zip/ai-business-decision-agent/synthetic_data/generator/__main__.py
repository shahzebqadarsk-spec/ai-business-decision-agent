from __future__ import annotations

import argparse
import json
from pathlib import Path

from generator.config import GeneratorConfig
from generator.pipeline import generate


def main() -> None:
    parser = argparse.ArgumentParser(prog="generator", description="PakManufacture synthetic data generator")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", type=str, default="synthetic_data/output")
    parser.add_argument(
        "--config", type=str, default=None, help="Unused placeholder for a future config file."
    )
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--no-messy", action="store_true")
    parser.add_argument("--skip-verify", action="store_true")
    args = parser.parse_args()

    config = GeneratorConfig(seed=args.seed, scale=args.scale, write_messy=not args.no_messy)
    result = generate(config, Path(args.output), skip_verify=args.skip_verify)
    print(json.dumps(result, indent=2))

    if result["verification_problems"]:
        raise SystemExit(f"Verification found {len(result['verification_problems'])} problem(s).")


if __name__ == "__main__":
    main()
