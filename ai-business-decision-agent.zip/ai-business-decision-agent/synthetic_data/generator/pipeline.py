"""Top-level orchestrator: assemble -> measure/ground-truth -> messy variant -> verify -> write."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from generator.assemble import assemble_dataset
from generator.config import GeneratorConfig
from generator.ground_truth import build_ground_truth
from generator.messy import build_messy_dataset
from generator.rng import make_streams
from generator.verify import verify_tables
from generator.writer import write_dataset


def generate(config: GeneratorConfig, output_dir: Path, *, skip_verify: bool = False) -> dict[str, Any]:
    streams = make_streams(config.seed)
    tables = assemble_dataset(config, streams)
    ground_truth = build_ground_truth(config, tables)

    messy_tables: dict[str, Any] | None = None
    messy_defects: list[dict[str, Any]] | None = None
    if config.write_messy:
        messy_tables, messy_defects = build_messy_dataset(config, tables, streams.stream("messy.defects"))

    problems: list[str] = []
    if not skip_verify:
        problems = verify_tables(tables, scale=config.scale)

    write_dataset(
        output_dir,
        tables,
        ground_truth,
        messy_tables=messy_tables,
        messy_defects=messy_defects,
        write_messy=config.write_messy,
    )

    return {
        "seed": config.seed,
        "output_dir": str(output_dir),
        "row_counts": {name: len(df) for name, df in tables.items()},
        "verification_problems": problems,
        "ground_truth_issue_ids": [issue["id"] for issue in ground_truth["issues"]],
        "wrote_messy": config.write_messy,
    }
