"""Monthly operating-expense generation (non-COGS overhead: rent, utilities, admin, logistics)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from generator.catalog import PLANTS
from generator.config import GeneratorConfig
from generator.macro import cpi_index, months

_EXPENSE_CATEGORIES: dict[str, float] = {
    "rent": 850_000.0,
    "utilities": 1_400_000.0,
    "admin": 600_000.0,
    "logistics": 950_000.0,
    "maintenance": 500_000.0,
}


def generate_expenses(config: GeneratorConfig, rng_noise: np.random.Generator) -> pd.DataFrame:
    month_list = months()
    cpi = cpi_index(month_list)

    rows: list[dict[str, object]] = []
    for m in month_list:
        for plant in PLANTS:
            for category, base_amount in _EXPENSE_CATEGORIES.items():
                noise = float(rng_noise.normal(loc=1.0, scale=0.05))
                amount = round(base_amount / len(PLANTS) * cpi[m] * noise, 2)
                rows.append(
                    {
                        "month": m.isoformat(),
                        "plant_id": plant.id,
                        "expense_category": category,
                        "amount_pkr": amount,
                        "currency": config.currency,
                    }
                )
    return pd.DataFrame(rows)
