"""Payroll and overtime generation, driven by line-level workload derived from sales demand.

Overtime on a line rises when the labor-hours implied by that line's demand
exceeds the standard-hours capacity of the employees assigned to it. Because
LINE-05 both (a) carries CAT-02's extra growth ramp and (b) has fewer
employees than its peers (the planted staffing gap, see `dimensions.py`),
its overtime should rise materially over the series while other lines stay
comparatively flat -- without any row being labelled as the "planted" one.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from generator.catalog import CATEGORY_PRIMARY_LINE, LINES
from generator.config import GeneratorConfig
from generator.dimensions import Employee
from generator.macro import months

_STANDARD_HOURS_PER_EMPLOYEE_MONTH = 208.0
_OVERTIME_PREMIUM_MULTIPLIER = 1.5
_LABOR_HOURS_PER_UNIT: dict[str, float] = {
    "CAT-01": 0.015,
    "CAT-02": 0.150,
    "CAT-03": 0.030,
    "CAT-04": 0.045,
}
_CAPACITY_UTILISATION_FACTOR = 0.92  # absence/changeover allowance


def _quantity_by_category_month(sales: pd.DataFrame) -> dict[tuple[str, str], float]:
    grouped = sales.groupby(["month", "category_id"])["quantity"].sum().reset_index()
    result: dict[tuple[str, str], float] = {}
    for row in grouped.itertuples(index=False):
        result[(str(row.month), str(row.category_id))] = float(row.quantity)  # type: ignore[arg-type]
    return result


def generate_workforce(
    config: GeneratorConfig,
    employees: tuple[Employee, ...],
    sales: pd.DataFrame,
    rng_noise: np.random.Generator,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Returns (payroll_df, overtime_df) -- one row per employee per month, and one
    summary row per line per month, respectively."""

    month_list = months()
    qty_by_cat_month = _quantity_by_category_month(sales)

    employees_by_line: dict[str, list[Employee]] = {}
    for emp in employees:
        employees_by_line.setdefault(emp.line_id, []).append(emp)

    category_by_line: dict[str, list[str]] = {}
    for cat, line_id in CATEGORY_PRIMARY_LINE.items():
        category_by_line.setdefault(line_id, []).append(cat)

    overtime_rows: list[dict[str, object]] = []
    payroll_rows: list[dict[str, object]] = []

    for m in month_list:
        for line in LINES:
            line_employees = employees_by_line.get(line.id, [])
            categories = category_by_line.get(line.id, [])
            workload_hours = sum(
                qty_by_cat_month.get((m.isoformat(), cat), 0.0) * _LABOR_HOURS_PER_UNIT[cat]
                for cat in categories
            )
            capacity_hours = (
                len(line_employees) * _STANDARD_HOURS_PER_EMPLOYEE_MONTH * _CAPACITY_UTILISATION_FACTOR
            )
            overtime_hours = max(0.0, workload_hours - capacity_hours)

            overtime_rows.append(
                {
                    "month": m.isoformat(),
                    "line_id": line.id,
                    "plant_id": line.plant_id,
                    "headcount": len(line_employees),
                    "workload_hours": round(workload_hours, 2),
                    "capacity_hours": round(capacity_hours, 2),
                    "overtime_hours": round(overtime_hours, 2),
                }
            )

            if not line_employees:
                continue
            overtime_per_employee = overtime_hours / len(line_employees)
            for emp in line_employees:
                noise = float(rng_noise.normal(loc=1.0, scale=0.05))
                emp_overtime_hours = max(0.0, overtime_per_employee * noise)
                overtime_pay = round(
                    emp_overtime_hours * emp.hourly_rate_pkr * _OVERTIME_PREMIUM_MULTIPLIER, 2
                )
                payroll_rows.append(
                    {
                        "month": m.isoformat(),
                        "employee_id": emp.id,
                        "plant_id": emp.plant_id,
                        "line_id": emp.line_id,
                        "base_salary_pkr": emp.monthly_base_salary_pkr,
                        "overtime_hours": round(emp_overtime_hours, 2),
                        "overtime_pay_pkr": overtime_pay,
                        "total_pay_pkr": round(emp.monthly_base_salary_pkr + overtime_pay, 2),
                        "currency": config.currency,
                    }
                )

    return pd.DataFrame(payroll_rows), pd.DataFrame(overtime_rows)
