"""Builds the intentionally-messy dataset variant: a copy of the clean tables with
deliberate, deterministic data-quality defects injected, for Phase 2's ingestion/profiling/
data-quality pipeline to exercise. The manifest of what was injected is hidden (never
exposed to ingestion/API) so Phase 2's detectors have to actually find the defects rather
than being told where they are.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from generator.config import GeneratorConfig


def build_messy_dataset(
    config: GeneratorConfig, tables: dict[str, pd.DataFrame], rng: np.random.Generator
) -> tuple[dict[str, pd.DataFrame], list[dict[str, Any]]]:
    messy = {name: df.copy() for name, df in tables.items()}
    defects: list[dict[str, Any]] = []

    sales = messy["sales"]
    n = len(sales)

    # 1. Missing values: blank out ~0.8% of discount_pct and ~0.5% of region_id.
    missing_discount_idx = rng.choice(n, size=max(1, int(n * 0.008)), replace=False)
    sales.loc[missing_discount_idx, "discount_pct"] = np.nan
    defects.append(
        {
            "type": "missing_values",
            "table": "sales",
            "column": "discount_pct",
            "row_count": len(missing_discount_idx),
        }
    )
    missing_region_idx = rng.choice(n, size=max(1, int(n * 0.005)), replace=False)
    sales.loc[missing_region_idx, "region_id"] = None
    defects.append(
        {
            "type": "missing_values",
            "table": "sales",
            "column": "region_id",
            "row_count": len(missing_region_idx),
        }
    )

    # 2. Duplicate records: re-append ~0.3% of rows verbatim with the same sale_id.
    dup_idx = rng.choice(n, size=max(1, int(n * 0.003)), replace=False)
    duplicated_rows = sales.iloc[dup_idx]
    sales = pd.concat([sales, duplicated_rows], ignore_index=True)
    defects.append({"type": "duplicate_records", "table": "sales", "row_count": len(dup_idx)})

    # 3. Invalid dates: corrupt a few order_date values to malformed strings.
    invalid_date_idx = rng.choice(len(sales), size=max(1, int(n * 0.001)), replace=False)
    sales.loc[invalid_date_idx, "order_date"] = "2025-13-45"
    defects.append(
        {
            "type": "invalid_dates",
            "table": "sales",
            "column": "order_date",
            "row_count": len(invalid_date_idx),
        }
    )

    # 4. Impossible numeric values: a handful of negative quantities / zero prices.
    impossible_idx = rng.choice(len(sales), size=max(1, int(n * 0.0015)), replace=False)
    half = len(impossible_idx) // 2
    sales.loc[impossible_idx[:half], "quantity"] = -1
    sales.loc[impossible_idx[half:], "unit_price_pkr"] = 0.0
    defects.append(
        {
            "type": "impossible_numeric_values",
            "table": "sales",
            "columns": ["quantity", "unit_price_pkr"],
            "row_count": len(impossible_idx),
        }
    )

    # 5. Inconsistent categorical values: vary casing/spelling of payment_terms.
    casing_idx = rng.choice(len(sales), size=max(1, int(n * 0.01)), replace=False)
    variant_map = {"NET30": "net30", "NET60": "Net-60", "NET15": "net 15"}
    sales.loc[casing_idx, "payment_terms"] = sales.loc[casing_idx, "payment_terms"].map(
        lambda v: variant_map.get(v, v.lower())
    )
    defects.append(
        {
            "type": "inconsistent_categorical_values",
            "table": "sales",
            "column": "payment_terms",
            "row_count": len(casing_idx),
        }
    )

    # 6. Suspicious outliers: a few absurdly large quantities, well outside the normal range.
    outlier_idx = rng.choice(len(sales), size=max(1, int(n * 0.0008)), replace=False)
    sales.loc[outlier_idx, "quantity"] = sales.loc[outlier_idx, "quantity"] * 500
    defects.append(
        {"type": "suspicious_outliers", "table": "sales", "column": "quantity", "row_count": len(outlier_idx)}
    )

    # 7. Referential-integrity issues: a few rows pointing at a customer_id that doesn't exist.
    orphan_idx = rng.choice(len(sales), size=max(1, int(n * 0.0006)), replace=False)
    sales.loc[orphan_idx, "customer_id"] = "CUST-9999"
    defects.append(
        {
            "type": "referential_integrity",
            "table": "sales",
            "column": "customer_id",
            "row_count": len(orphan_idx),
            "note": "CUST-9999 does not exist in customers.csv",
        }
    )

    # 8. Schema inconsistency: rename a column on the messy copy only.
    sales = sales.rename(columns={"net_amount_pkr": "net_amount"})
    defects.append(
        {
            "type": "schema_inconsistency",
            "table": "sales",
            "note": "net_amount_pkr renamed to net_amount in the messy variant only",
        }
    )

    messy["sales"] = sales
    return messy, defects
