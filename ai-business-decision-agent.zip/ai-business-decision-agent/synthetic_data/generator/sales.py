"""Sales line-item generation.

Target volume: ~150k-300k rows across the 36-month series (the Phase 1 spec's
sizing requirement). Row count and growth are controlled by two constants:

- `_BASE_LINES_PER_MONTH`: average number of order lines per month before
  growth/seasonality, calibrated so the full 36-month, scale=1.0 series lands
  in the middle of the target band.
- `_growth_factor`: a company-wide linear volume ramp over the series, with
  an extra convex ramp for CAT-02 (Knitwear) -- this is what eventually
  pushes the Knitting line (LINE-05) toward capacity and makes the planted
  staffing-gap overtime problem (GT-04) show up only in later months, the
  way a real capacity problem would.
"""

from __future__ import annotations

from datetime import timedelta

import numpy as np
import pandas as pd

from generator.catalog import CATEGORY_PRIMARY_LINE, PRODUCTS, PRODUCTS_BY_ID
from generator.config import GeneratorConfig
from generator.dimensions import Customer
from generator.macro import cpi_index, fx_usd_pkr, months, seasonality_factor
from generator.planted import (
    margin_decline_cost_multiplier,
    margin_decline_price_cap,
    red_herring_region_single_month_dip,
    red_herring_seasonal_product_spike,
    region_decline_factor,
)

_BASE_LINES_PER_MONTH = 5000.0
_GROWTH_OVER_SERIES = 0.6
_CAT02_EXTRA_GROWTH = 0.9
_CAT02_EXTRA_GROWTH_CATEGORY = "CAT-02"
_TOTAL_MONTHS = 36


def _growth_factor(month_idx: int, category_id: str) -> float:
    progress = month_idx / (_TOTAL_MONTHS - 1)
    factor = 1.0 + _GROWTH_OVER_SERIES * progress
    if category_id == _CAT02_EXTRA_GROWTH_CATEGORY:
        factor += _CAT02_EXTRA_GROWTH * progress**1.3
    return factor


def generate_sales(
    config: GeneratorConfig,
    customers: tuple[Customer, ...],
    rng_lines: np.random.Generator,
    rng_product: np.random.Generator,
    rng_qty: np.random.Generator,
    rng_noise: np.random.Generator,
) -> pd.DataFrame:
    month_list = months()
    cpi = cpi_index(month_list)
    fx = fx_usd_pkr(month_list)
    planted = config.planted

    customer_by_id = {c.id: c for c in customers}
    customer_ids = np.array([c.id for c in customers])
    customer_weights = np.array([c.order_weight for c in customers])
    customer_weights = customer_weights / customer_weights.sum()

    product_ids = np.array([p.id for p in PRODUCTS])
    # mild popularity skew so a handful of products dominate volume, without being as
    # extreme as the customer concentration curve.
    product_rank_weights = (np.arange(1, len(PRODUCTS) + 1).astype(float)) ** -0.4
    product_rank_weights = product_rank_weights / product_rank_weights.sum()
    product_weights = rng_product.permutation(product_rank_weights)

    rows: list[dict[str, object]] = []
    sale_counter = 0

    for m_idx, m in enumerate(month_list):
        seasonality = seasonality_factor(m)
        month_total_lines = max(20, int(round(_BASE_LINES_PER_MONTH * seasonality * config.scale)))

        # which customer each line belongs to, drawn once per month
        line_customers = rng_lines.choice(customer_ids, size=month_total_lines, p=customer_weights)
        # which product each line is for
        line_products = rng_product.choice(product_ids, size=month_total_lines, p=product_weights)

        for customer_id, product_id in zip(line_customers, line_products, strict=True):
            customer = customer_by_id[customer_id]
            product = PRODUCTS_BY_ID[product_id]
            category_id = product.category_id

            is_declining_region = customer.region_id == planted.region_decline_id
            # The declining region is deliberately excluded from the company-wide growth
            # ramp: its trend is the planted decline alone, not "decline net of growth",
            # which keeps the regional trend unambiguous rather than a race between two
            # opposing effects.
            growth = 1.0 if is_declining_region else _growth_factor(m_idx, category_id)
            region_factor = region_decline_factor(m_idx, planted) if is_declining_region else 1.0
            region_factor *= red_herring_region_single_month_dip(m_idx, region_id=customer.region_id)

            base_qty = rng_qty.lognormal(mean=2.1, sigma=0.55)
            noise = rng_noise.normal(loc=1.0, scale=0.08)
            quantity = max(1, round(base_qty * growth * region_factor * noise))

            price_factor = cpi[m] * red_herring_seasonal_product_spike(m.month, product_id=product_id)
            if product_id == planted.margin_decline_product_id:
                price_factor *= margin_decline_price_cap(m_idx, planted)
            unit_price = round(product.base_unit_price_pkr * price_factor, 2)

            cost_factor = cpi[m]
            if product_id == planted.margin_decline_product_id:
                cost_factor *= margin_decline_cost_multiplier(m_idx, planted)
            unit_cost = round(product.base_unit_cost_pkr * cost_factor, 2)

            gross_amount = round(quantity * unit_price, 2)
            discount_pct = round(float(rng_noise.uniform(0.0, 0.03)), 4)
            net_amount = round(gross_amount * (1 - discount_pct), 2)
            cogs_amount = round(quantity * unit_cost, 2)
            margin_amount = round(net_amount - cogs_amount, 2)
            margin_pct = round(margin_amount / net_amount, 4) if net_amount else 0.0

            order_date = m + timedelta(days=int(rng_noise.integers(0, 28)))
            lag_days = {"NET15": 15, "NET30": 30, "NET45": 45, "NET60": 60, "NET90": 90}[
                customer.payment_terms
            ]
            invoice_lag = int(rng_noise.integers(0, 5))
            invoice_date = order_date + timedelta(days=invoice_lag)
            due_date = invoice_date + timedelta(days=lag_days)

            sale_counter += 1
            rows.append(
                {
                    "sale_id": f"SALE-{sale_counter:07d}",
                    "month": m.isoformat(),
                    "order_date": order_date.isoformat(),
                    "invoice_date": invoice_date.isoformat(),
                    "due_date": due_date.isoformat(),
                    "customer_id": customer.id,
                    "region_id": customer.region_id,
                    "product_id": product.id,
                    "category_id": category_id,
                    "line_id": CATEGORY_PRIMARY_LINE[category_id],
                    "quantity": int(quantity),
                    "unit_price_pkr": unit_price,
                    "unit_cost_pkr": unit_cost,
                    "gross_amount_pkr": gross_amount,
                    "discount_pct": discount_pct,
                    "net_amount_pkr": net_amount,
                    "cogs_amount_pkr": cogs_amount,
                    "gross_margin_amount_pkr": margin_amount,
                    "gross_margin_pct": margin_pct,
                    "payment_terms": customer.payment_terms,
                    "fx_usd_pkr": round(fx[m], 4),
                    "currency": config.currency,
                }
            )

    return pd.DataFrame(rows)
