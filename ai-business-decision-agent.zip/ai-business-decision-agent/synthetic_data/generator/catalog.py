"""Static business catalog: regions, categories, products, suppliers, materials, plants/lines.

These are fixed lists, not randomly generated, so every seed shares the same
entity universe and only behaviour (demand, pricing, staffing, ...) varies
with the seed.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Region:
    id: str
    name: str


@dataclass(frozen=True)
class Category:
    id: str
    name: str


@dataclass(frozen=True)
class Product:
    id: str
    name: str
    category_id: str
    base_unit_price_pkr: float
    base_unit_cost_pkr: float


@dataclass(frozen=True)
class Supplier:
    id: str
    name: str


@dataclass(frozen=True)
class Material:
    id: str
    name: str
    default_supplier_id: str
    base_unit_cost_pkr: float


@dataclass(frozen=True)
class Plant:
    id: str
    name: str


@dataclass(frozen=True)
class ProductionLine:
    id: str
    plant_id: str
    name: str
    capacity_hours_per_month: float


REGIONS: tuple[Region, ...] = (
    Region("REG-01", "Punjab-North"),
    Region("REG-02", "Punjab-South"),
    Region("REG-03", "Sindh"),
    Region("REG-04", "KPK"),
    Region("REG-05", "Balochistan"),
)

CATEGORIES: tuple[Category, ...] = (
    Category("CAT-01", "Yarn"),
    Category("CAT-02", "Knitwear"),
    Category("CAT-03", "Woven Fabric"),
    Category("CAT-04", "Home Textiles"),
)

_PRODUCT_NAMES_BY_CATEGORY: dict[str, tuple[str, ...]] = {
    "CAT-01": (
        "Cotton Yarn 20s",
        "Cotton Yarn 30s",
        "Cotton Yarn 40s",
        "Blended Yarn 20s",
        "Blended Yarn 30s",
        "Polyester Yarn 150D",
    ),
    "CAT-02": (
        "Men's Crew T-Shirt",
        "Women's Crew T-Shirt",
        "Kids Polo Shirt",
        "Fleece Hoodie",
        "Ribbed Tank Top",
        "Jersey Dress",
        "Knit Joggers",
    ),
    "CAT-03": (
        "Denim Twill",
        "Poplin Shirting",
        "Canvas Fabric",
        "Drill Fabric",
        "Dobby Suiting",
        "Greige Fabric",
    ),
    "CAT-04": (
        "Bedsheet Set Queen",
        "Bedsheet Set King",
        "Bath Towel Set",
        "Terry Robe",
        "Table Linen Set",
        "Curtain Fabric",
    ),
}


def _build_products() -> tuple[Product, ...]:
    products: list[Product] = []
    counter = 0
    base_prices = {
        "CAT-01": (420.0, 80.0),
        "CAT-02": (950.0, 540.0),
        "CAT-03": (610.0, 360.0),
        "CAT-04": (1450.0, 820.0),
    }
    for category in CATEGORIES:
        for name in _PRODUCT_NAMES_BY_CATEGORY[category.id]:
            counter += 1
            price, cost = base_prices[category.id]
            # mild deterministic spread across products of the same category
            spread = 1.0 + ((counter % 5) - 2) * 0.05
            products.append(
                Product(
                    id=f"PROD-{counter:02d}",
                    name=name,
                    category_id=category.id,
                    base_unit_price_pkr=round(price * spread, 2),
                    base_unit_cost_pkr=round(cost * spread, 2),
                )
            )
    return tuple(products)


PRODUCTS: tuple[Product, ...] = _build_products()
assert len(PRODUCTS) == 25

SUPPLIERS: tuple[Supplier, ...] = tuple(
    Supplier(f"SUP-{i:02d}", f"{name} Textile Mills")
    for i, name in enumerate(
        (
            "Al-Rehman",
            "Chenab",
            "Faisalabad",
            "Lahore",
            "Sahiwal",
            "Multan",
            "Gujranwala",
            "Hyderabad",
            "Karachi",
            "Sialkot",
            "Bahawalpur",
            "Jhang",
        ),
        start=1,
    )
)

MATERIALS: tuple[Material, ...] = (
    Material("MAT-01", "Raw Cotton", "SUP-04", 185.0),
    Material("MAT-02", "Polyester Fiber", "SUP-07", 160.0),
    Material("MAT-03", "Dyes & Chemicals", "SUP-02", 310.0),
    Material("MAT-04", "Packaging Material", "SUP-09", 45.0),
    Material("MAT-05", "Buttons & Trims", "SUP-10", 12.0),
    Material("MAT-06", "Elastane Yarn", "SUP-07", 410.0),
    Material("MAT-07", "Grey Fabric", "SUP-03", 290.0),
    Material("MAT-08", "Finishing Chemicals", "SUP-02", 220.0),
)

PLANTS: tuple[Plant, ...] = (
    Plant("PLANT-01", "Faisalabad Composite Unit"),
    Plant("PLANT-02", "Lahore Knitting Unit"),
    Plant("PLANT-03", "Karachi Finishing Unit"),
)

LINES: tuple[ProductionLine, ...] = (
    ProductionLine("LINE-01", "PLANT-01", "Spinning 1", 2600.0),
    ProductionLine("LINE-02", "PLANT-01", "Spinning 2", 2600.0),
    ProductionLine("LINE-03", "PLANT-01", "Weaving 1", 2400.0),
    ProductionLine("LINE-04", "PLANT-02", "Knitting 1", 2200.0),
    ProductionLine("LINE-05", "PLANT-02", "Knitting 2", 2200.0),
    ProductionLine("LINE-06", "PLANT-02", "Cut & Sew", 2000.0),
    ProductionLine("LINE-07", "PLANT-03", "Dyeing", 2100.0),
    ProductionLine("LINE-08", "PLANT-03", "Finishing", 2100.0),
    ProductionLine("LINE-09", "PLANT-03", "Packing", 1800.0),
)

PRODUCTS_BY_ID: dict[str, Product] = {p.id: p for p in PRODUCTS}
CATEGORY_BY_ID: dict[str, Category] = {c.id: c for c in CATEGORIES}
MATERIAL_BY_ID: dict[str, Material] = {m.id: m for m in MATERIALS}
LINES_BY_PLANT: dict[str, tuple[ProductionLine, ...]] = {
    plant.id: tuple(line for line in LINES if line.plant_id == plant.id) for plant in PLANTS
}

# Each product category is primarily produced on one line, so plant-level workload
# (and the planted overtime problem on LINE-05) is causally tied to category-level demand.
CATEGORY_PRIMARY_LINE: dict[str, str] = {
    "CAT-01": "LINE-01",
    "CAT-02": "LINE-05",
    "CAT-03": "LINE-03",
    "CAT-04": "LINE-08",
}
