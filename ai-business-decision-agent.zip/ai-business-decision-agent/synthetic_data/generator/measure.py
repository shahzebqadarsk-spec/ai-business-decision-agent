"""Pure measurement functions that recover each planted problem from written output tables.

These are used both to build `ground_truth.yaml` (the `as_generated` values) and by the
test suite, which re-derives the same numbers independently from the files on disk -- the
measurement functions never read `planted.py`'s multipliers directly, only the tables that
generation actually wrote.
"""

from __future__ import annotations

import pandas as pd

_BASELINE_MONTHS = ("2024-10-01", "2024-11-01", "2024-12-01")  # just before the GT-01 window starts
_FINAL_QUARTER_MONTHS = ("2025-10-01", "2025-11-01", "2025-12-01")
_FIRST_QUARTER_MONTHS = ("2023-01-01", "2023-02-01", "2023-03-01")


def measure_procurement_increase(
    purchase_df: pd.DataFrame,
    *,
    supplier_id: str,
    material_id: str,
    cpi_by_month: dict[str, float] | None = None,
) -> float:
    """Relative change in real (CPI-deflated, when `cpi_by_month` given) unit price for one
    supplier/material pair, comparing the quarter just before the planted window to the
    final quarter. Deflating isolates the supplier-specific repricing from the macro
    inflation that affects every material's nominal price over the 3-year span -- without
    it, this metric would conflate the planted ~17% effect with cumulative CPI drift."""
    subset = purchase_df[
        (purchase_df["supplier_id"] == supplier_id) & (purchase_df["material_id"] == material_id)
    ].copy()
    if cpi_by_month:
        cpi_for_row = subset["month"].map(cpi_by_month).fillna(1.0)
        subset["_real_price"] = subset["unit_price_pkr"] / cpi_for_row
    else:
        subset["_real_price"] = subset["unit_price_pkr"]

    baseline = subset[subset["month"].isin(_BASELINE_MONTHS)]["_real_price"].mean()
    final = subset[subset["month"].isin(_FINAL_QUARTER_MONTHS)]["_real_price"].mean()
    if pd.isna(baseline) or baseline == 0:
        return 0.0
    return float((final - baseline) / baseline)


def measure_region_decline(sales_df: pd.DataFrame, *, region_id: str) -> float:
    subset = sales_df[sales_df["region_id"] == region_id]
    first = subset[subset["month"].isin(_FIRST_QUARTER_MONTHS)]["net_amount_pkr"].sum()
    last = subset[subset["month"].isin(_FINAL_QUARTER_MONTHS)]["net_amount_pkr"].sum()
    if first == 0:
        return 0.0
    return float((last - first) / first)


def measure_margin_decline(sales_df: pd.DataFrame, *, product_id: str) -> float:
    subset = sales_df[sales_df["product_id"] == product_id]
    first = subset[subset["month"].isin(_FIRST_QUARTER_MONTHS)]["gross_margin_pct"].mean()
    last = subset[subset["month"].isin(_FINAL_QUARTER_MONTHS)]["gross_margin_pct"].mean()
    if pd.isna(first) or pd.isna(last):
        return 0.0
    return float(first - last)  # positive = margin deteriorated


def measure_overtime_rise(overtime_df: pd.DataFrame, *, line_id: str) -> float:
    subset = overtime_df[overtime_df["line_id"] == line_id]
    last = subset[subset["month"].isin(_FINAL_QUARTER_MONTHS)]["overtime_hours"].mean()
    return float(last) if not pd.isna(last) else 0.0


def measure_inventory_imbalance(inventory_df: pd.DataFrame, *, product_id: str) -> float:
    """Months-of-cover (closing stock / average monthly shipments) in the final quarter."""
    subset = inventory_df[inventory_df["product_id"] == product_id]
    final = subset[subset["month"].isin(_FINAL_QUARTER_MONTHS)]
    avg_shipped = final["shipped_units"].mean()
    avg_closing = final["closing_stock_units"].mean()
    if not avg_shipped:
        return 0.0
    return float(avg_closing / avg_shipped)
