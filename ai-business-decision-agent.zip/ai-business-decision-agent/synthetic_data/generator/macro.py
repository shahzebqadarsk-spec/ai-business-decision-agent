"""Month axis, macro-economic indices (CPI, FX) and seasonality.

These are deterministic functions of calendar month only (no RNG stream of
their own) so every seed shares the same macro backdrop and only
entity-level behaviour varies with the seed -- matching how a real analyst
would expect inflation/FX to be a shared external fact, not something that
differs company to company.
"""

from __future__ import annotations

from datetime import date

START_YEAR = 2023
START_MONTH = 1
NUM_MONTHS = 36

# ~0.6%/month compounding -> roughly +24% cumulative inflation over 36 months,
# consistent with Pakistan's elevated-but-moderating CPI environment in this period.
_MONTHLY_CPI_RATE = 0.006
# PKR gradually depreciates against USD over the window.
_MONTHLY_FX_DRIFT = 0.004
_BASE_USD_PKR = 280.0


def months() -> list[date]:
    result = []
    year, month = START_YEAR, START_MONTH
    for _ in range(NUM_MONTHS):
        result.append(date(year, month, 1))
        month += 1
        if month > 12:
            month = 1
            year += 1
    return result


def month_index(d: date) -> int:
    return (d.year - START_YEAR) * 12 + (d.month - START_MONTH)


def cpi_index(month_list: list[date]) -> dict[date, float]:
    """CPI level per month, base=1.0 at the first month."""
    return {m: (1.0 + _MONTHLY_CPI_RATE) ** month_index(m) for m in month_list}


def fx_usd_pkr(month_list: list[date]) -> dict[date, float]:
    return {m: _BASE_USD_PKR * (1.0 + _MONTHLY_FX_DRIFT) ** month_index(m) for m in month_list}


# Textile demand seasonality: peaks ahead of Eid/summer (Mar-May) and winter home-textile
# season (Oct-Dec); a trough in the monsoon low season (Jul-Aug).
_SEASONALITY_BY_CALENDAR_MONTH: dict[int, float] = {
    1: 0.95,
    2: 1.00,
    3: 1.12,
    4: 1.15,
    5: 1.08,
    6: 0.98,
    7: 0.88,
    8: 0.90,
    9: 1.00,
    10: 1.10,
    11: 1.15,
    12: 1.05,
}


def seasonality_factor(d: date) -> float:
    return _SEASONALITY_BY_CALENDAR_MONTH[d.month]
