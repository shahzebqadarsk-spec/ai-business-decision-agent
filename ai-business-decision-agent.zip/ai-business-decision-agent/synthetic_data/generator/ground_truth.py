"""Builds the hidden ground_truth.yaml -- never read by the backend/ingestion/AI during
normal operation (see tests/synthetic/test_isolation.py, which greps app/ source for any
import of this module)."""

from __future__ import annotations

from typing import Any

import pandas as pd

from generator.config import GeneratorConfig
from generator.macro import cpi_index, months
from generator.measure import (
    measure_inventory_imbalance,
    measure_margin_decline,
    measure_overtime_rise,
    measure_procurement_increase,
    measure_region_decline,
)


def build_ground_truth(config: GeneratorConfig, tables: dict[str, pd.DataFrame]) -> dict[str, Any]:
    planted = config.planted
    cpi_by_month = {m.isoformat(): v for m, v in cpi_index(months()).items()}

    gt_01 = measure_procurement_increase(
        tables["procurement"],
        supplier_id=planted.procurement_supplier_id,
        material_id=planted.procurement_material_id,
        cpi_by_month=cpi_by_month,
    )
    gt_02 = measure_region_decline(tables["sales"], region_id=planted.region_decline_id)
    gt_03 = measure_margin_decline(tables["sales"], product_id=planted.margin_decline_product_id)
    gt_04 = measure_overtime_rise(tables["overtime"], line_id=planted.overtime_line_id)
    gt_05 = measure_inventory_imbalance(
        tables["inventory"], product_id=planted.inventory_imbalance_product_id
    )

    issues = [
        {
            "id": "GT-01",
            "category": "procurement",
            "description": "Procurement cost increase concentrated in one supplier/material pair.",
            "affected_entities": {
                "supplier_id": planted.procurement_supplier_id,
                "material_id": planted.procurement_material_id,
            },
            "expected_direction": "increase",
            "expected_magnitude_range": [0.12, 0.24],
            "as_generated": round(gt_01, 4),
            "time_period": "last 4 quarters (2025 Q1-Q4)",
            "expected_rca_driver": (
                "CPI-deflated unit price for MAT-01 purchased from SUP-04 rises materially "
                "faster than the macro inflation baseline, concentrated in that one "
                "supplier/material relationship."
            ),
        },
        {
            "id": "GT-02",
            "category": "region",
            "description": "One region shows a meaningful declining sales trend.",
            "affected_entities": {"region_id": planted.region_decline_id},
            "expected_direction": "decrease",
            "expected_magnitude_range": [-0.35, -0.10],
            "as_generated": round(gt_02, 4),
            "time_period": "2023-01 to 2025-12",
            "expected_rca_driver": (
                f"Net sales revenue for {planted.region_decline_id} declines steadily across "
                "the series, not explained by seasonality or a single bad month."
            ),
        },
        {
            "id": "GT-03",
            "category": "product_margin",
            "description": "One product shows deteriorating gross margin.",
            "affected_entities": {"product_id": planted.margin_decline_product_id},
            "expected_direction": "decrease",
            "expected_magnitude_range": [0.05, 0.18],
            "as_generated": round(gt_03, 4),
            "time_period": "2023-01 to 2025-12",
            "expected_rca_driver": (
                f"Unit cost for {planted.margin_decline_product_id} rises faster than its "
                "price can follow, steadily compressing gross-margin percentage."
            ),
        },
        {
            "id": "GT-04",
            "category": "overtime",
            "description": "Overtime rises materially, concentrated on one production line/staffing gap.",
            "affected_entities": {"line_id": planted.overtime_line_id, "plant_id": "PLANT-02"},
            "expected_direction": "increase",
            "expected_magnitude_range": [50.0, 1600.0],
            "as_generated": round(gt_04, 2),
            "time_period": "2025 Q4 average monthly overtime hours",
            "expected_rca_driver": (
                f"{planted.overtime_line_id} is understaffed relative to its peer lines "
                "(a deliberate staffing gap) while the category it produces (CAT-02, "
                "Knitwear) carries above-average demand growth, pushing workload past "
                "standard-hours capacity."
            ),
        },
        {
            "id": "GT-05",
            "category": "inventory",
            "description": "One product shows a meaningful inventory overstock pattern.",
            "affected_entities": {"product_id": planted.inventory_imbalance_product_id},
            "expected_direction": "increase",
            "expected_magnitude_range": [1.5, 7.0],
            "as_generated": round(gt_05, 2),
            "time_period": "2025 Q4 average months-of-cover",
            "expected_rca_driver": (
                f"Production for {planted.inventory_imbalance_product_id} runs ahead of "
                "shipments by a growing margin, building up finished-goods stock without "
                "a matching increase in demand."
            ),
        },
    ]

    red_herrings = [
        {
            "id": "RH-01",
            "description": "PROD-04 (a yarn product) spikes every Mar/Apr (Ramadan/Eid season) "
            "but fully reverts -- a seasonal pattern, not a trend.",
        },
        {
            "id": "RH-02",
            "description": "SUP-11 has one isolated price spike in month 15 (2024-03) that fully "
            "reverts the next month -- unlike the planted, sustained GT-01 repricing.",
        },
        {
            "id": "RH-03",
            "description": "REG-02 has one unusually weak month (2023-08) with no underlying "
            "trend -- unlike the planted, steady GT-02 decline.",
        },
    ]

    return {
        "generator_seed": config.seed,
        "locked_decisions": {
            "start_month": config.start_month.isoformat(),
            "months": config.months,
            "currency": config.currency,
        },
        "issues": issues,
        "red_herrings": red_herrings,
    }
