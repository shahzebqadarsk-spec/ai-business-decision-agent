"""Production and finished-goods-inventory generation.

Production is built to order (production ratio ~= 1.0 against that month's
shipments) for every product except the one planted overstock product,
where the ratio rises over the series via `inventory_overstock_bias`. Stock
is then rebuilt purely from the written production/shipment flows
(`closing = opening + production - shipped`), so the inventory identity is
trivially re-checkable from the output files alone -- no separate "true"
inventory number has to be trusted.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from generator.catalog import CATEGORY_PRIMARY_LINE, PRODUCTS, PRODUCTS_BY_ID
from generator.config import GeneratorConfig
from generator.macro import months
from generator.planted import inventory_overstock_bias


def _shipped_by_product_month(sales: pd.DataFrame) -> dict[tuple[str, str], int]:
    grouped = sales.groupby(["month", "product_id"])["quantity"].sum().reset_index()
    result: dict[tuple[str, str], int] = {}
    for row in grouped.itertuples(index=False):
        result[(str(row.month), str(row.product_id))] = int(row.quantity)  # type: ignore[arg-type]
    return result


def generate_supply(
    config: GeneratorConfig, sales: pd.DataFrame, rng_noise: np.random.Generator
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Returns (production_df, inventory_df)."""
    month_list = months()
    shipped_by = _shipped_by_product_month(sales)
    planted = config.planted

    production_rows: list[dict[str, object]] = []
    inventory_rows: list[dict[str, object]] = []

    opening_stock: dict[str, float] = {
        p.id: max(50.0, shipped_by.get((month_list[0].isoformat(), p.id), 100) * 1.15) for p in PRODUCTS
    }

    for m_idx, m in enumerate(month_list):
        for product in PRODUCTS:
            shipped = shipped_by.get((m.isoformat(), product.id), 0)
            production_ratio = 1.0
            if product.id == planted.inventory_imbalance_product_id:
                production_ratio = inventory_overstock_bias(m_idx, planted)
            noise = float(rng_noise.normal(loc=1.0, scale=0.04))
            produced = max(0, round(shipped * production_ratio * noise))

            opening = opening_stock[product.id]
            closing = opening + produced - shipped

            production_rows.append(
                {
                    "month": m.isoformat(),
                    "product_id": product.id,
                    "line_id": CATEGORY_PRIMARY_LINE[PRODUCTS_BY_ID[product.id].category_id],
                    "quantity_produced": int(produced),
                }
            )
            inventory_rows.append(
                {
                    "month": m.isoformat(),
                    "product_id": product.id,
                    "opening_stock_units": round(opening, 2),
                    "produced_units": produced,
                    "shipped_units": shipped,
                    "closing_stock_units": round(closing, 2),
                }
            )
            opening_stock[product.id] = closing

    return pd.DataFrame(production_rows), pd.DataFrame(inventory_rows)
