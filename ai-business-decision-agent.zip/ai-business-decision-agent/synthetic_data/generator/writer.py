"""Writes the assembled tables (and, optionally, the messy variant and hidden fixtures) to disk."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
import yaml


def write_dataset(
    output_dir: Path,
    tables: dict[str, pd.DataFrame],
    ground_truth: dict[str, Any],
    *,
    messy_tables: dict[str, pd.DataFrame] | None = None,
    messy_defects: list[dict[str, Any]] | None = None,
    write_messy: bool = True,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    clean_dir = output_dir / "clean"
    clean_dir.mkdir(parents=True, exist_ok=True)
    for name, df in tables.items():
        df.to_csv(clean_dir / f"{name}.csv", index=False)

    hidden_dir = output_dir / "_hidden"
    hidden_dir.mkdir(parents=True, exist_ok=True)
    with (hidden_dir / "ground_truth.yaml").open("w") as fh:
        yaml.safe_dump(ground_truth, fh, sort_keys=False)

    if write_messy and messy_tables is not None:
        messy_dir = output_dir / "messy"
        messy_dir.mkdir(parents=True, exist_ok=True)
        for name, df in messy_tables.items():
            df.to_csv(messy_dir / f"{name}.csv", index=False)
        with (hidden_dir / "messy_defects.yaml").open("w") as fh:
            yaml.safe_dump({"defects": messy_defects or []}, fh, sort_keys=False)
