"""Deterministic, named random-number-generator streams.

Every component of the generator that needs randomness asks for its own
named stream derived from the run seed. Because each stream's `SeedSequence`
mixes the run seed with a stable hash of the stream's *name* (not its call
order), adding a brand-new random draw anywhere in the codebase can never
perturb the numbers any other, unrelated component produces for the same
seed. That property is what makes `test_determinism.py` and the
cross-seed-robustness checks meaningful.
"""

from __future__ import annotations

import zlib

import numpy as np


class StreamFactory:
    def __init__(self, seed: int) -> None:
        self._seed = seed

    def stream(self, name: str) -> np.random.Generator:
        name_hash = zlib.crc32(name.encode("utf-8"))
        seed_sequence = np.random.SeedSequence([self._seed, name_hash])
        return np.random.Generator(np.random.PCG64(seed_sequence))


def make_streams(seed: int) -> StreamFactory:
    return StreamFactory(seed)
