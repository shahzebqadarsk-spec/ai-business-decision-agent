"""Scaled/randomised dimensions: customers and employees.

Regions, categories, products, suppliers, materials, plants and lines are
static (see `catalog.py`); customers and employees are the two dimensions
whose *count* and *attributes* vary with `scale` and the seed.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from generator.catalog import LINES, REGIONS
from generator.config import GeneratorConfig

PAYMENT_TERMS = ("NET15", "NET30", "NET45", "NET60", "NET90")
_PAYMENT_TERMS_WEIGHTS = (0.15, 0.40, 0.20, 0.15, 0.10)


@dataclass(frozen=True)
class Customer:
    id: str
    name: str
    region_id: str
    payment_terms: str
    order_weight: float  # relative order frequency/size; Zipf-concentrated


@dataclass(frozen=True)
class Employee:
    id: str
    plant_id: str
    line_id: str
    monthly_base_salary_pkr: float
    hourly_rate_pkr: float


def build_customers(config: GeneratorConfig, rng: np.random.Generator) -> tuple[Customer, ...]:
    n = config.effective_sizes.customers
    region_ids = [r.id for r in REGIONS]
    regions_for_customers = rng.choice(region_ids, size=n)
    terms_for_customers = rng.choice(PAYMENT_TERMS, size=n, p=_PAYMENT_TERMS_WEIGHTS)

    # Fixed Zipf curve shape (exponent) with *randomised* rank assignment, so the degree
    # of concentration is seed-robust while which specific customer is "the whale" is not.
    ranks = np.arange(1, n + 1)
    weights = ranks.astype(float) ** -0.85
    weights = weights / weights.sum()
    shuffled_weights = rng.permutation(weights)

    customers = []
    for i in range(n):
        customers.append(
            Customer(
                id=f"CUST-{i + 1:04d}",
                name=f"Customer {i + 1:04d}",
                region_id=str(regions_for_customers[i]),
                payment_terms=str(terms_for_customers[i]),
                order_weight=float(shuffled_weights[i]),
            )
        )
    return tuple(customers)


def build_employees(config: GeneratorConfig, rng: np.random.Generator) -> tuple[Employee, ...]:
    n = config.effective_sizes.employees
    all_lines = list(LINES)
    gap_line_id = config.planted.overtime_line_id
    gap = config.planted.staffing_gap

    # Proportional base allocation across lines, then apply the planted staffing gap to
    # one specific line and redistribute the *actually removed* headcount (not the nominal
    # `gap`) to the other lines -- otherwise a small/scaled roster could have fewer than
    # `gap` employees on that line to begin with, and naively adding the nominal gap back
    # elsewhere would inflate total headcount above `n`.
    base_count = n // len(all_lines)
    remainder = n - base_count * len(all_lines)
    counts: dict[str, int] = {}
    for i, line in enumerate(all_lines):
        counts[line.id] = base_count + (1 if i < remainder else 0)

    original_count = counts[gap_line_id]
    counts[gap_line_id] = max(1, original_count - gap)
    actually_removed = original_count - counts[gap_line_id]

    other_line_ids = [line.id for line in all_lines if line.id != gap_line_id]
    for i in range(actually_removed):
        counts[other_line_ids[i % len(other_line_ids)]] += 1

    assert sum(counts.values()) == n

    lines_by_id = {line.id: line for line in all_lines}
    salaries = rng.normal(loc=38000.0, scale=6000.0, size=n).clip(min=22000.0)

    employees = []
    idx = 0
    for line in all_lines:
        for _ in range(counts[line.id]):
            salary = float(salaries[idx])
            employees.append(
                Employee(
                    id=f"EMP-{idx + 1:04d}",
                    plant_id=lines_by_id[line.id].plant_id,
                    line_id=line.id,
                    monthly_base_salary_pkr=round(salary, 2),
                    hourly_rate_pkr=round(salary / 208.0, 2),  # 26 days x 8 hours
                )
            )
            idx += 1
    return tuple(employees)
