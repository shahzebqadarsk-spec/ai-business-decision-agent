-- Read-only role for analytics/BI tools; granted SELECT only, after migrations run.
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'abda_readonly') THEN
    CREATE ROLE abda_readonly LOGIN PASSWORD :'analytics_password';
  END IF;
END
$$;
GRANT CONNECT ON DATABASE abda TO abda_readonly;
